﻿namespace uovapp
{
    partial class ConfirmatinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelconform = new System.Windows.Forms.Label();
            this.labelfncf = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelemail = new System.Windows.Forms.Label();
            this.labelmobilecf = new System.Windows.Forms.Label();
            this.groupBoxcf = new System.Windows.Forms.GroupBox();
            this.labelha = new System.Windows.Forms.Label();
            this.labelexen = new System.Windows.Forms.Label();
            this.labelcr = new System.Windows.Forms.Label();
            this.labelhostelcon = new System.Windows.Forms.Label();
            this.labelexamcon = new System.Windows.Forms.Label();
            this.labelcoursecon = new System.Windows.Forms.Label();
            this.labelfncon = new System.Windows.Forms.Label();
            this.labelemailcon = new System.Windows.Forms.Label();
            this.labelmobilecon = new System.Windows.Forms.Label();
            this.btnconfirm = new System.Windows.Forms.Button();
            this.labellnconf = new System.Windows.Forms.Label();
            this.labeldobcof = new System.Windows.Forms.Label();
            this.labeldobcf = new System.Windows.Forms.Label();
            this.groupBoxcf.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelconform
            // 
            this.labelconform.AutoSize = true;
            this.labelconform.Font = new System.Drawing.Font("Segoe Script", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelconform.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.labelconform.Location = new System.Drawing.Point(29, 26);
            this.labelconform.Name = "labelconform";
            this.labelconform.Size = new System.Drawing.Size(497, 31);
            this.labelconform.TabIndex = 0;
            this.labelconform.Text = "Thanks for SignUp...We will contact you soon....";
            // 
            // labelfncf
            // 
            this.labelfncf.AutoSize = true;
            this.labelfncf.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelfncf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.labelfncf.Location = new System.Drawing.Point(65, 73);
            this.labelfncf.Name = "labelfncf";
            this.labelfncf.Size = new System.Drawing.Size(138, 24);
            this.labelfncf.TabIndex = 2;
            this.labelfncf.Text = "Your FirstName";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(65, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Your LastName";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelemail
            // 
            this.labelemail.AutoSize = true;
            this.labelemail.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelemail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.labelemail.Location = new System.Drawing.Point(65, 169);
            this.labelemail.Name = "labelemail";
            this.labelemail.Size = new System.Drawing.Size(164, 24);
            this.labelemail.TabIndex = 6;
            this.labelemail.Text = "Your EmailAddress";
            // 
            // labelmobilecf
            // 
            this.labelmobilecf.AutoSize = true;
            this.labelmobilecf.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmobilecf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.labelmobilecf.Location = new System.Drawing.Point(65, 215);
            this.labelmobilecf.Name = "labelmobilecf";
            this.labelmobilecf.Size = new System.Drawing.Size(180, 24);
            this.labelmobilecf.TabIndex = 8;
            this.labelmobilecf.Text = "Your Mobile Number";
            // 
            // groupBoxcf
            // 
            this.groupBoxcf.Controls.Add(this.labelha);
            this.groupBoxcf.Controls.Add(this.labelexen);
            this.groupBoxcf.Controls.Add(this.labelcr);
            this.groupBoxcf.Controls.Add(this.labelhostelcon);
            this.groupBoxcf.Controls.Add(this.labelexamcon);
            this.groupBoxcf.Controls.Add(this.labelcoursecon);
            this.groupBoxcf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxcf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.groupBoxcf.Location = new System.Drawing.Point(69, 297);
            this.groupBoxcf.Name = "groupBoxcf";
            this.groupBoxcf.Size = new System.Drawing.Size(346, 159);
            this.groupBoxcf.TabIndex = 10;
            this.groupBoxcf.TabStop = false;
            this.groupBoxcf.Text = "Services you Choose";
            // 
            // labelha
            // 
            this.labelha.AutoSize = true;
            this.labelha.Location = new System.Drawing.Point(6, 116);
            this.labelha.Name = "labelha";
            this.labelha.Size = new System.Drawing.Size(215, 20);
            this.labelha.TabIndex = 20;
            this.labelha.Text = "Hostel Accommodation Form";
            // 
            // labelexen
            // 
            this.labelexen.AutoSize = true;
            this.labelexen.Location = new System.Drawing.Point(6, 79);
            this.labelexen.Name = "labelexen";
            this.labelexen.Size = new System.Drawing.Size(131, 20);
            this.labelexen.TabIndex = 19;
            this.labelexen.Text = "Exam Entry Form";
            // 
            // labelcr
            // 
            this.labelcr.AutoSize = true;
            this.labelcr.Location = new System.Drawing.Point(6, 38);
            this.labelcr.Name = "labelcr";
            this.labelcr.Size = new System.Drawing.Size(191, 20);
            this.labelcr.TabIndex = 18;
            this.labelcr.Text = "Course Registration Form";
            // 
            // labelhostelcon
            // 
            this.labelhostelcon.AutoSize = true;
            this.labelhostelcon.Location = new System.Drawing.Point(311, 116);
            this.labelhostelcon.Name = "labelhostelcon";
            this.labelhostelcon.Size = new System.Drawing.Size(20, 20);
            this.labelhostelcon.TabIndex = 17;
            this.labelhostelcon.Text = "X";
            // 
            // labelexamcon
            // 
            this.labelexamcon.AutoSize = true;
            this.labelexamcon.Location = new System.Drawing.Point(311, 79);
            this.labelexamcon.Name = "labelexamcon";
            this.labelexamcon.Size = new System.Drawing.Size(20, 20);
            this.labelexamcon.TabIndex = 16;
            this.labelexamcon.Text = "X";
            // 
            // labelcoursecon
            // 
            this.labelcoursecon.AutoSize = true;
            this.labelcoursecon.Location = new System.Drawing.Point(311, 38);
            this.labelcoursecon.Name = "labelcoursecon";
            this.labelcoursecon.Size = new System.Drawing.Size(20, 20);
            this.labelcoursecon.TabIndex = 15;
            this.labelcoursecon.Text = "X";
            // 
            // labelfncon
            // 
            this.labelfncon.AutoSize = true;
            this.labelfncon.Location = new System.Drawing.Point(286, 81);
            this.labelfncon.Name = "labelfncon";
            this.labelfncon.Size = new System.Drawing.Size(22, 13);
            this.labelfncon.TabIndex = 11;
            this.labelfncon.Text = ".....";
            this.labelfncon.Click += new System.EventHandler(this.labelfncon_Click);
            // 
            // labelemailcon
            // 
            this.labelemailcon.AutoSize = true;
            this.labelemailcon.Location = new System.Drawing.Point(286, 177);
            this.labelemailcon.Name = "labelemailcon";
            this.labelemailcon.Size = new System.Drawing.Size(22, 13);
            this.labelemailcon.TabIndex = 13;
            this.labelemailcon.Text = ".....";
            // 
            // labelmobilecon
            // 
            this.labelmobilecon.AutoSize = true;
            this.labelmobilecon.Location = new System.Drawing.Point(286, 226);
            this.labelmobilecon.Name = "labelmobilecon";
            this.labelmobilecon.Size = new System.Drawing.Size(22, 13);
            this.labelmobilecon.TabIndex = 14;
            this.labelmobilecon.Text = ".....";
            // 
            // btnconfirm
            // 
            this.btnconfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnconfirm.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnconfirm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnconfirm.Location = new System.Drawing.Point(384, 443);
            this.btnconfirm.Name = "btnconfirm";
            this.btnconfirm.Size = new System.Drawing.Size(91, 35);
            this.btnconfirm.TabIndex = 15;
            this.btnconfirm.Text = "Confirm";
            this.btnconfirm.UseVisualStyleBackColor = false;
            this.btnconfirm.Click += new System.EventHandler(this.btnconfirm_Click);
            // 
            // labellnconf
            // 
            this.labellnconf.AutoSize = true;
            this.labellnconf.Location = new System.Drawing.Point(286, 128);
            this.labellnconf.Name = "labellnconf";
            this.labellnconf.Size = new System.Drawing.Size(22, 13);
            this.labellnconf.TabIndex = 16;
            this.labellnconf.Text = ".....";
            // 
            // labeldobcof
            // 
            this.labeldobcof.AutoSize = true;
            this.labeldobcof.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldobcof.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.labeldobcof.Location = new System.Drawing.Point(75, 260);
            this.labeldobcof.Name = "labeldobcof";
            this.labeldobcof.Size = new System.Drawing.Size(159, 24);
            this.labeldobcof.TabIndex = 17;
            this.labeldobcof.Text = "Your Date of Birth";
            // 
            // labeldobcf
            // 
            this.labeldobcf.AutoSize = true;
            this.labeldobcf.Location = new System.Drawing.Point(286, 260);
            this.labeldobcf.Name = "labeldobcf";
            this.labeldobcf.Size = new System.Drawing.Size(22, 13);
            this.labeldobcf.TabIndex = 18;
            this.labeldobcf.Text = ".....";
            // 
            // ConfirmatinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 490);
            this.Controls.Add(this.labeldobcf);
            this.Controls.Add(this.labeldobcof);
            this.Controls.Add(this.labellnconf);
            this.Controls.Add(this.btnconfirm);
            this.Controls.Add(this.labelmobilecon);
            this.Controls.Add(this.labelemailcon);
            this.Controls.Add(this.labelfncon);
            this.Controls.Add(this.groupBoxcf);
            this.Controls.Add(this.labelmobilecf);
            this.Controls.Add(this.labelemail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelfncf);
            this.Controls.Add(this.labelconform);
            this.Name = "ConfirmatinForm";
            this.Text = "ConfirmatinForm";
            this.Load += new System.EventHandler(this.ConfirmatinForm_Load);
            this.groupBoxcf.ResumeLayout(false);
            this.groupBoxcf.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelconform;
        private System.Windows.Forms.Label labelfncf;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelemail;
        private System.Windows.Forms.Label labelmobilecf;
        private System.Windows.Forms.GroupBox groupBoxcf;
        private System.Windows.Forms.Label labelha;
        private System.Windows.Forms.Label labelexen;
        private System.Windows.Forms.Label labelcr;
        private System.Windows.Forms.Label labelhostelcon;
        private System.Windows.Forms.Label labelexamcon;
        private System.Windows.Forms.Label labelcoursecon;
        private System.Windows.Forms.Label labelfncon;
        private System.Windows.Forms.Label labelemailcon;
        private System.Windows.Forms.Label labelmobilecon;
        private System.Windows.Forms.Button btnconfirm;
        private System.Windows.Forms.Label labellnconf;
        private System.Windows.Forms.Label labeldobcof;
        private System.Windows.Forms.Label labeldobcf;
    }
}